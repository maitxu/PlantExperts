# PlantExpert — Implementación inicial del motor de inferencia

## Archivos
- `PlantExpert_motor_inferencia.pl`: reglas y predicados del motor en SWI-Prolog.
- `PlantExpert_pruebas_motor.py`: pruebas de comportamiento que invocan SWI-Prolog.

## Encadenamiento hacia delante
El motor recibe hechos conocidos, recorre todas las reglas y devuelve todas aquellas cuyos requisitos están presentes. Por ejemplo, los hechos `manchas_marrones` y `anillos_concentricos` activan la hipótesis preliminar `alternariosis`.

## Encadenamiento hacia atrás
Se pregunta por una conclusión concreta, por ejemplo: «¿hay hechos que respalden alternariosis?». El predicado `ejemplo_hacia_atras/3` comprueba los requisitos de esa causa. Si falta `anillos_concentricos`, devuelve los datos pendientes en vez de afirmar que la causa está respaldada.

## Respuestas incompletas
Se pasan por separado:
- `HechosSi`: respuestas afirmativas.
- `Desconocidos`: preguntas cuya respuesta se desconoce.
- `NoComprobados`: preguntas que todavía no se han revisado.

El motor no trata automáticamente un dato ausente como falso. Si no hay hipótesis y quedan datos pendientes, devuelve `informacion_insuficiente`. Si no hay hipótesis ni datos pendientes registrados, devuelve `ninguna_regla_encaja`.

## Varias causas
Todas las reglas compatibles se devuelven. Esto es intencionado: por ejemplo, si se marcan a la vez `marchitez`, `suelo_seco` y `suelo_encharcado`, el sistema presenta ambas hipótesis de riego como una señal de respuestas incompatibles que deben revisarse. En la interfaz final conviene impedir que se seleccione simultáneamente suelo seco y encharcado para el mismo momento de observación.

## Cómo ejecutar las pruebas
1. Instalar SWI-Prolog y asegurarse de que `swipl` está disponible en la terminal.
2. Guardar ambos archivos en la misma carpeta.
3. Ejecutar `python PlantExpert_pruebas_motor.py`.

Las pruebas se omiten automáticamente si no se encuentra `swipl`. La implementación es un prototipo didáctico: las reglas son preliminares, deben revisarse con las fuentes del proyecto y no confirman enfermedades.
