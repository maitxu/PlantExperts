% PlantExpert — motor de inferencia inicial
% SWI-Prolog
%
% Los hechos son síntomas confirmados por la persona usuaria.
% Los datos desconocidos/no comprobados se guardan por separado.
% Una hipótesis no equivale a un diagnóstico confirmado.

:- module(plant_expert,
          [ responder/4,
            regla/2,
            ejemplo_hacia_atras/3
          ]).

% regla(Causa, ListaDeHechosNecesarios).
% Reglas preliminares: deben revisarse junto con las fuentes técnicas del proyecto.

regla(alternariosis,
      [manchas_marrones, anillos_concentricos]).

regla(oidio,
      [manchas_amarillas, crecimiento_blanco_enves]).

regla(mildiu_tardio,
      [lesiones_irregulares_acuosas, crecimiento_blanco_enves]).

regla(mancha_bacteriana,
      [manchas_pequenas_oscuras, halo_amarillo]).

regla(mancha_bacteriana,
      [lesiones_fruto_asperas_oscuras]).

regla(estres_por_falta_de_agua,
      [marchitez, suelo_seco]).

regla(posible_exceso_de_agua_o_problema_radicular,
      [marchitez, suelo_encharcado]).

% Esta regla sugiere investigar nutrición; no identifica un nutriente concreto.
regla(problema_nutricional_a_investigar,
      [amarilleo, patron_amarilleo_entre_hojas]).

% Una regla se activa solo si TODOS sus requisitos están entre los hechos positivos.
todos_presentes([], _).
todos_presentes([H|T], Hechos) :-
    memberchk(H, Hechos),
    todos_presentes(T, Hechos).

% Devuelve las hipótesis y los hechos que justifican cada una.
hipotesis_activada(Hechos, hipotesis(Causa, Requisitos)) :-
    regla(Causa, Requisitos),
    todos_presentes(Requisitos, Hechos).

% responder(+HechosSi, +Desconocidos, +NoComprobados, -Respuesta)
%
% Respuesta:
%   resultado(estado, hipótesis, datos_pendientes)
%
% estado puede ser:
%   hipotesis_generadas
%   informacion_insuficiente
%   ninguna_regla_encaja
%
% Para evitar confundir ausencia con falsedad, los síntomas no indicados
% no se consideran automáticamente síntomas descartados.
responder(HechosSi, Desconocidos, NoComprobados,
          resultado(Estado, Hipotesis, Pendientes)) :-
    findall(H, hipotesis_activada(HechosSi, H), Todas),
    quitar_duplicados(Todas, Hipotesis),
    append(Desconocidos, NoComprobados, P0),
    quitar_duplicados(P0, Pendientes),
    determinar_estado(Hipotesis, Pendientes, Estado).

determinar_estado(Hipotesis, _, hipotesis_generadas) :-
    Hipotesis \= [],
    !.
determinar_estado([], Pendientes, informacion_insuficiente) :-
    Pendientes \= [],
    !.
determinar_estado([], [], ninguna_regla_encaja).

quitar_duplicados(Lista, SinDuplicados) :-
    sort(Lista, SinDuplicados).

% Ejemplo de encadenamiento hacia atrás:
% se pregunta si una causa concreta está respaldada por los hechos.
% Resultado:
%   respaldada(Requisitos)
%   faltan_datos(RequisitosPendientes, RequisitosConocidos)
%   no_hay_regla_para_esa_causa
ejemplo_hacia_atras(Causa, Hechos, Resultado) :-
    findall(Req, regla(Causa, Req), Conjuntos),
    ( Conjuntos = [] ->
        Resultado = no_hay_regla_para_esa_causa
    ; member(Req, Conjuntos),
      todos_presentes(Req, Hechos) ->
        Resultado = respaldada(Req)
    ; member(Req, Conjuntos),
      subtract(Req, Hechos, Faltan),
      Resultado = faltan_datos(Faltan, Req)
    ).
