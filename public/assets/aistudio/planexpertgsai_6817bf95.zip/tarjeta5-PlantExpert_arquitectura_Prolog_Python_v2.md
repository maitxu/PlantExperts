# PlantExpert — Arquitectura y tecnologías con Prolog y Python (versión 2)

## 1. Objetivo
PlantExpert es un prototipo académico que ayuda a explorar posibles causas de problemas en tomateras de huerto al aire libre en Euskadi. No confirma diagnósticos: muestra hipótesis compatibles, qué hechos las activan, qué información falta y las fuentes que respaldan las reglas.

Problemas iniciales: alternariosis, oídio, mildiu tardío, mancha bacteriana, problemas de riego y problemas nutricionales.

## 2. Esquema de los cinco componentes

```mermaid
flowchart TD
    A[1. Interfaz de usuario - Python / Streamlit] -->|Respuestas y hechos| B[2. Base de conocimiento - Prolog]
    B <--> C[3. Motor de inferencia - Prolog]
    C -->|Hipótesis, reglas activadas y datos faltantes| D[4. Módulo de explicación - Python]
    D -->|Resultado comprensible| A
    E[5. Actualización del conocimiento - revisión y pruebas] -->|Reglas aprobadas| B
```

La base de conocimiento y el motor de inferencia son componentes conceptualmente distintos, aunque pueden residir en archivos Prolog dentro del mismo proyecto. Python se comunica con Prolog mediante una interfaz como PySwip o Janus. Google AI Studio/Gemini es opcional y no forma parte del núcleo de inferencia.

## 3. Función de cada componente

### 1. Interfaz de usuario — Python con Streamlit
Un formulario recoge:
- Órgano afectado: hojas, tallo o fruto.
- Síntomas y forma/distribución de las manchas.
- Presencia de crecimiento blanco.
- Humedad del suelo y regularidad del riego.
- Evolución del problema y condiciones recientes.

Cada respuesta debe distinguir entre observado, no observado, no comprobado y desconocido. Streamlit permite construir una pequeña aplicación web con Python. La interfaz valida y transmite las respuestas; no decide por sí misma la causa.

### 2. Base de conocimiento — archivos Prolog
Los hechos y reglas centrales se guardarán en archivos `.pl`. Los hechos representan información conocida; las reglas representan relaciones que permiten inferir posibles causas. La regla debe incluir o enlazar su identificador de fuente y sus limitaciones. Una tabla CSV puede mantenerse como catálogo de revisión humana, pero Prolog será la representación ejecutable del conocimiento.

Ejemplo ilustrativo, no regla clínica definitiva:
```prolog
posible_causa(alternariosis) :-
    mancha_marron,
    anillos_concentricos.
```
La regla real deberá documentar la fuente, aclarar que la coincidencia no confirma la enfermedad y evaluarse junto a otras causas.

### 3. Motor de inferencia — Prolog
Prolog consulta los hechos introducidos y evalúa qué reglas se cumplen. Su mecanismo de unificación y búsqueda permite obtener cero, una o varias soluciones. Es una buena elección porque la lógica IF–THEN y el razonamiento son el centro de la tarea académica.

El motor no debe forzar una sola respuesta: si varias causas encajan, devuelve varias hipótesis; si los datos son insuficientes, debe indicarlo. “Desconocido” no se tratará como “no”. No se inventarán porcentajes de confianza.

### 4. Módulo de explicación — Python
Python recoge las soluciones de Prolog y las presenta con lenguaje sencillo:
- Hipótesis que conviene considerar.
- Síntomas observados que activaron la regla.
- Datos que faltan o no se han comprobado.
- Otras causas posibles.
- Fuente y limitaciones de la regla.

En la primera versión conviene usar plantillas de texto controladas, enlazadas a las reglas. Así la explicación es trazable y no depende de que un modelo generativo invente una justificación.

### 5. Actualización del conocimiento — revisión y pruebas
1. Consultar una fuente técnica fiable.
2. Proponer una regla y registrar fuente, fecha de consulta y limitaciones.
3. Comprobar que las condiciones sean observables y específicas.
4. Probar casos donde la regla debe activarse y casos donde no debe activarse.
5. Revisar solapamientos y contradicciones con las reglas existentes.
6. Aprobar el cambio, guardar una versión y documentar qué cambió.

La actualización no será automática. Una regla generada por IA no se incorpora sin revisión humana.

## 4. ¿Por qué Prolog?
- Representa hechos y reglas de forma explícita.
- Está diseñado para hacer consultas mediante inferencia lógica.
- Permite ver y explicar qué regla se ha activado.
- Se ajusta al objetivo didáctico de estudiar sistemas expertos y conocimiento basado en reglas.

## 5. ¿Por qué Python?
- Simplifica la interfaz y la validación de respuestas.
- Se integra con Prolog mediante herramientas existentes.
- Permite presentar resultados y gestionar las referencias.
- Facilita futuras extensiones, por ejemplo guardar sesiones o analizar datos.

## 6. Tecnologías elegidas

| Tecnología | Papel en el proyecto | Justificación |
|---|---|---|
| SWI-Prolog | Hechos, reglas y motor de inferencia | Implementación práctica de Prolog con documentación y opciones de integración con Python. |
| Python 3 | Orquestación, validación y presentación de resultados | Código legible y ecosistema amplio. |
| Streamlit (propuesta) | Interfaz web | Permite crear formularios y resultados con poco código Python. |
| PySwip o Janus | Comunicación Python–Prolog | Permite consultar Prolog desde Python. Se escogerá una sola opción tras comprobar compatibilidad con el entorno. |
| Archivos `.pl` | Conocimiento ejecutable | Mantienen los hechos y reglas explícitos y versionables. |
| CSV | Tabla de síntomas y revisión | Facilita revisar las seis causas y sus fuentes. |
| Git | Control de versiones | Conserva el historial de cambios del código y del conocimiento. |
| Google AI Studio / Gemini API (opcional) | Prototipar o generar explicaciones en lenguaje natural | Aporta experimentación con IA, pero no es necesario para que funcione el sistema experto. |

## 7. ¿Por qué Google AI Studio si usamos Prolog y Python?
Google AI Studio permite probar instrucciones y experimentar con modelos Gemini; cuando se quiera integrar el modelo en una aplicación, la documentación oficial explica cómo obtener código de inicio para la Gemini API. Gemini también puede devolver salidas estructuradas según un esquema definido.

En PlantExpert puede utilizarse para probar explicaciones en lenguaje natural, por ejemplo convertir una lista de reglas activadas en un texto fácil de entender. No obstante, para la primera versión no es imprescindible. La recomendación es implementar primero el motor Prolog y la interfaz Python; después, si aporta valor, probar Gemini como módulo opcional.

**Distinción fundamental:** Prolog decide qué reglas lógicas se cumplen; Python gestiona la aplicación y muestra el resultado; Gemini, si se añade, puede ayudar a redactar. Gemini no debe sustituir el motor ni inventar reglas, fuentes o certeza diagnóstica.

Documentación oficial:
- Google AI Studio quickstart: https://ai.google.dev/gemini-api/docs/ai-studio-quickstart
- Salidas estructuradas de Gemini: https://ai.google.dev/gemini-api/docs/structured-output
- SWI-Prolog, integración con Python: https://www.swi-prolog.org/FAQ/Python.md
- PySwip: https://pypi.org/project/pyswip/
- Janus: https://www.swi-prolog.org/pldoc/man?section=janus-intro
- Streamlit: https://docs.streamlit.io/

## 8. Seguridad y límites
- Mantener las fuentes vinculadas a cada regla.
- No confirmar un diagnóstico solo por una fotografía o un síntoma inespecífico.
- No mostrar porcentajes sin un método validado.
- No recomendar tratamientos fitosanitarios automáticamente.
- Si se utiliza Gemini API, guardar la clave en un entorno seguro y no subirla al repositorio.
- Indicar cuándo la información no basta y cuándo conviene consultar a una persona especialista.

## 9. Pruebas mínimas
- Las reglas se activan cuando se cumplen sus condiciones.
- No se activan si falta una condición obligatoria.
- Un dato desconocido no se interpreta como negativo.
- Los síntomas compartidos pueden devolver varias hipótesis.
- Cada hipótesis muestra regla, fuente y limitaciones.
- Si no hay coincidencias suficientes, el sistema indica que falta información.
- Las reglas nuevas pasan pruebas y revisión antes de incorporarse.

## 10. Decisión final
Para la primera versión se propone: **SWI-Prolog + Python 3 + Streamlit + interfaz de integración Prolog/Python + archivos `.pl` y CSV + Git**. Google AI Studio/Gemini será opcional y se valorará después de que funcione el núcleo experto.
