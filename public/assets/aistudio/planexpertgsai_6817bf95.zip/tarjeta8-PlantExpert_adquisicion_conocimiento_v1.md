# PlantExpert — Diseño de adquisición de nuevo conocimiento (versión 1)

## 1. Objetivo y relación con la arquitectura

Este procedimiento define cómo investigar, registrar, revisar, incorporar y probar conocimiento nuevo en PlantExpert, el sistema experto educativo para problemas de tomateras de huerto al aire libre en Euskadi.

Se mantiene la arquitectura elegida:
- Prolog: hechos, reglas y motor de inferencia.
- Python (con Streamlit como propuesta): interfaz, validación y presentación de resultados.
- CSV: tabla de síntomas para revisión humana.
- Git: control de versiones.
- Google AI Studio/Gemini: opcional; no aprueba ni incorpora reglas automáticamente.

### ¿Es necesario terminar antes el sistema de explicación?
No. Se puede diseñar e iniciar la adquisición de conocimiento antes de implementar el módulo de explicación. Sin embargo, cada regla debe guardar su fuente, justificación, limitaciones e identificador desde el principio. Así, el módulo de explicación podrá usar esos metadatos después sin rediseñar la base de conocimiento.

## 2. Conocimiento inicial que debe conservarse

El proyecto parte de seis grupos ya investigados:
1. Alternariosis.
2. Oídio.
3. Mildiu tardío.
4. Mancha bacteriana.
5. Problemas de riego.
6. Problemas nutricionales.

Las reglas existentes en `PlantExpert_motor_inferencia.pl` son preliminares y usan la forma `regla(Causa, ListaDeHechos)`. El procedimiento de esta guía conserva ese formato para no romper el motor actual. Los metadatos de la regla se registran en una ficha asociada; se puede formalizar su lectura desde Prolog/Python en una iteración posterior.

## 3. Procedimiento para añadir un problema nuevo

### Paso 1. Definir el problema
- Asignar un nombre claro y un identificador estable.
- Determinar si es una enfermedad infecciosa, un problema ambiental, de riego, nutricional u otra categoría.
- Comprobar que no esté ya representado con otro nombre.
- Especificar qué plantas y contexto cubre la evidencia. Para el alcance actual: tomateras de huerto al aire libre en Euskadi.

### Paso 2. Investigar fuentes
Priorizar, en este orden:
1. Fuentes oficiales y servicios fitosanitarios.
2. Universidades y servicios de extensión agrícola.
3. Artículos científicos revisados por pares o manuales técnicos reconocidos.

Registrar el título, entidad/autores, URL exacta, fecha de consulta y qué afirmación concreta respalda la fuente. Una fuente general sobre tomates no respalda necesariamente cada detalle de una regla.

### Paso 3. Describir síntomas observables
Para cada síntoma indicar:
- Nombre normalizado para el sistema.
- Órgano afectado (hoja, tallo, fruto, planta completa).
- Descripción observable y, si procede, patrón, forma o evolución.
- Si es obligatorio para la regla o solo información complementaria.
- Si también puede aparecer en otras causas.

Evitar términos ambiguos como “la planta está mal” o usar un síntoma compartido como única condición para afirmar una causa.

### Paso 4. Redactar reglas pequeñas y comprobables
Usar reglas `IF–THEN` con condiciones observables y suficientes para sugerir una hipótesis. Mantener la salida como “posible causa” o “causa a considerar”, no como diagnóstico confirmado.

En el motor actual, la representación es:

```prolog
regla(causa_nueva, [hecho_1, hecho_2]).
```

Esta es solo la parte ejecutable de la regla. La fuente y las limitaciones deben registrarse también en la ficha de conocimiento. No se debe incorporar una regla sin fuente trazable.

### Paso 5. Registrar la ficha de la regla
Cada regla debe documentar como mínimo:
- `id_regla`
- `problema`
- `condiciones`
- `resultado_sugerido`
- `fuente_titulo`
- `fuente_entidad`
- `fuente_url`
- `fecha_consulta`
- `justificacion`
- `limitaciones`
- `alternativas`
- `estado_revision` (borrador, en revisión, aprobada, retirada)
- `version`

No confundir “no observado” con “no comprobado” ni con “desconocido”. El motor actual solo dispara reglas si todos sus requisitos están presentes entre los hechos afirmativos; la interfaz debe mantener por separado las respuestas desconocidas y no comprobadas.

### Paso 6. Revisión humana antes de incorporarla
Otra persona del equipo, o la persona responsable de la revisión, comprobará:
- Que la fuente existe y respalda las condiciones y conclusión.
- Que los síntomas son observables y no excesivamente generales.
- Que la conclusión no afirma más de lo que permite la evidencia.
- Que se consideran síntomas compartidos y causas alternativas.
- Que no se infiere un nutriente concreto solo por un amarilleo inespecífico.
- Que las recomendaciones no incluyan tratamientos fitosanitarios automáticos.

Mientras no se revise, la regla permanece como borrador y no se usa en la versión estable.

## 4. Comprobar que no contradiga las reglas existentes

Antes de aprobar una regla:
1. Comparar sus condiciones con las reglas de las seis causas actuales.
2. Buscar síntomas compartidos que puedan activar varias hipótesis.
3. Revisar combinaciones incompatibles de respuestas, por ejemplo marcar simultáneamente `suelo_seco` y `suelo_encharcado` para la misma observación.
4. Comprobar que una respuesta desconocida no se interprete como ausencia del síntoma.
5. Comprobar que la regla nueva no suprima una hipótesis alternativa sin una razón documentada.

Que dos reglas se activen con los mismos hechos no es necesariamente una contradicción: puede ser un diagnóstico diferencial correcto. Es una contradicción lógica o de diseño si las reglas producen resultados incompatibles para el mismo estado de hechos, o si una regla descarta injustificadamente otra causa.

## 5. Pruebas obligatorias tras cada actualización

Para cada regla nueva preparar casos esperados antes de probarla:

- **Caso positivo:** se cumplen todos los requisitos; la regla debe activarse.
- **Caso negativo:** falta una condición obligatoria; la regla no debe activarse.
- **Caso incompleto:** una condición está desconocida o no comprobada; no se debe asumir que es verdadera ni falsa.
- **Caso ambiguo:** se cumplen reglas de varias causas; deben mostrarse todas las hipótesis compatibles.
- **Regresión:** ejecutar también las pruebas del motor que ya existen para verificar que las reglas anteriores siguen funcionando.
- **Trazabilidad:** comprobar que cada hipótesis tiene una fuente y una limitación registradas.

Las pruebas de `PlantExpert_pruebas_motor.py` deben ejecutarse en un equipo con SWI-Prolog disponible en el PATH. Si una prueba falla, no se aprueba ni publica la actualización hasta revisar el fallo.

## 6. ¿Se actualiza desde el código o desde una interfaz?

### Decisión para la primera versión: desde el código
La primera versión será académica y pequeña. Por ello, se añadirán las reglas editando `PlantExpert_motor_inferencia.pl` y registrando la ficha de conocimiento en la documentación/tabla del proyecto. Después se ejecutarán las pruebas y se guardará el cambio en Git.

Ventajas:
- Es fácil revisar exactamente qué cambió.
- Evita que una persona introduzca accidentalmente una regla sin fuente.
- No requiere construir todavía una pantalla de administración.

### Posible mejora futura: interfaz de administración
Si el catálogo crece, se podría crear una pantalla en Streamlit para proponer una regla y completar sus metadatos. La interfaz no debería activarla directamente: la nueva regla quedaría como borrador, necesitaría revisión humana y solo se exportaría al conocimiento activo después de superar las pruebas.

Google AI Studio/Gemini puede ayudar a resumir una fuente o proponer un borrador, pero la fuente debe verificarse y la aprobación debe ser humana.

## 7. Versionado y registro de cambios

Por cada actualización registrar:
- Fecha.
- Persona responsable de la modificación/revisión.
- Regla añadida, modificada o retirada.
- Fuente consultada.
- Pruebas ejecutadas y resultado.
- Motivo del cambio.

Guardar el código y las fichas en Git. No sobrescribir el historial: si una regla resulta errónea, corregirla o retirarla mediante un cambio versionado.

## 8. Plantilla de alta

```text
ID de regla:
Problema:
Categoría:
Órgano afectado:
Condiciones observables:
Hechos Prolog:
Conclusión que se mostrará:
Fuente (título y entidad):
URL:
Fecha de consulta:
Justificación basada en la fuente:
Síntomas compartidos / alternativas:
Limitaciones:
Caso positivo de prueba:
Caso negativo de prueba:
Caso incompleto o ambiguo:
Estado: borrador / en revisión / aprobada / retirada
Versión:
```

## 9. Checklist de aceptación

- [ ] El problema nuevo está definido y no duplica otro existente.
- [ ] Cada síntoma está descrito de forma observable.
- [ ] Cada regla tiene una fuente técnica exacta y una justificación.
- [ ] Las limitaciones y alternativas están documentadas.
- [ ] Una persona revisó la regla antes de activarla.
- [ ] Se revisaron solapamientos y contradicciones.
- [ ] Se probaron casos positivos, negativos, incompletos y ambiguos.
- [ ] Se ejecutaron las pruebas de regresión del motor.
- [ ] Se actualizó el registro de cambios en Git.
- [ ] La regla aprobada conserva los metadatos que necesitará el módulo de explicación.

## 10. Criterio de finalización

El procedimiento se considera definido cuando el equipo puede incorporar un nuevo problema siguiendo los pasos anteriores y demostrar con pruebas que la regla se comporta como se espera, conserva una fuente trazable y no rompe las reglas existentes.

Este documento define el proceso; no significa que ya se haya incorporado una enfermedad adicional al motor.
