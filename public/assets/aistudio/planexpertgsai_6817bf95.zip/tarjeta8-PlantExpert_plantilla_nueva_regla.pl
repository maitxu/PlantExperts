% PlantExpert — plantilla para una regla nueva
% Copiar y adaptar solo tras verificar una fuente técnica.
% Mantener la forma compatible con PlantExpert_motor_inferencia.pl.

% 1) Regla ejecutable:
% regla(causa_nueva, [hecho_observable_1, hecho_observable_2]).

% 2) Registrar los metadatos en la ficha de conocimiento del proyecto:
% ID de regla:
% Problema:
% Fuente (título y entidad):
% URL exacta:
% Fecha de consulta:
% Justificación:
% Limitaciones y causas alternativas:
% Casos de prueba positivos, negativos e incompletos:
% Estado: borrador / en revisión / aprobada / retirada

% No activar esta regla hasta completar la revisión humana y las pruebas.
