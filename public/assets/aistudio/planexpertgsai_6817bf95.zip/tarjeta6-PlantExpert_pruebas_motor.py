"""Casos de prueba de referencia para PlantExpert.

Estas pruebas describen el comportamiento esperado del motor Prolog.
Para ejecutarlas se necesita SWI-Prolog instalado y accesible mediante `swipl`.
Comando: python PlantExpert_pruebas_motor.py
"""
import shutil
import subprocess
import sys
import unittest
from pathlib import Path

PROLOG = shutil.which("swipl")
RULES = Path(__file__).with_name("PlantExpert_motor_inferencia.pl")


@unittest.skipUnless(PROLOG, "No se encontró SWI-Prolog en PATH; las pruebas no se ejecutan.")
class MotorPlantExpertTests(unittest.TestCase):
    def consulta(self, goal):
        # Ejecuta una consulta aislada sobre el archivo Prolog.
        cmd = [
            PROLOG, "-q", "-s", str(RULES),
            "-g", goal,
            "-t", "halt"
        ]
        return subprocess.run(cmd, capture_output=True, text=True, check=False)

    def test_alternariosis_con_dos_sintomas(self):
        r = self.consulta(
            "plant_expert:responder([manchas_marrones,anillos_concentricos],[],[],R),"
            "write_canonical(R),nl"
        )
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("alternariosis", r.stdout)
        self.assertIn("hipotesis_generadas", r.stdout)

    def test_muestra_varias_causas(self):
        r = self.consulta(
            "plant_expert:responder([marchitez],[],[],R),"
            "write_canonical(R),nl"
        )
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("ninguna_regla_encaja", r.stdout)

        r = self.consulta(
            "plant_expert:responder([manchas_amarillas,crecimiento_blanco_enves,"
            "lesiones_irregulares_acuosas],[],[],R),write_canonical(R),nl"
        )
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("oidio", r.stdout)
        self.assertIn("mildiu_tardio", r.stdout)

    def test_respuestas_incompletas(self):
        r = self.consulta(
            "plant_expert:responder([marchitez],[suelo_humedad_desconocida],[],R),"
            "write_canonical(R),nl"
        )
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("informacion_insuficiente", r.stdout)

    def test_ninguna_regla_encaja(self):
        r = self.consulta(
            "plant_expert:responder([hojas_caidas],[],[],R),"
            "write_canonical(R),nl"
        )
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("ninguna_regla_encaja", r.stdout)

    def test_encadenamiento_hacia_atras(self):
        r = self.consulta(
            "plant_expert:ejemplo_hacia_atras(alternariosis,"
            "[manchas_marrones],R),write_canonical(R),nl"
        )
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("faltan_datos", r.stdout)
        self.assertIn("anillos_concentricos", r.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
